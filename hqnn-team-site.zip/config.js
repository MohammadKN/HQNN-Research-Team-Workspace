// Fill these in after deploying Code.gs (see README.md).
window.CONFIG = {
  API_URL: "PASTE_YOUR_WEB_APP_URL_HERE", // the Apps Script web app URL ending in /exec
  TOKEN: "CHANGE_ME_SECRET",              // must match TOKEN at the top of Code.gs
  POLL_MS: 8000                           // how often the page re-reads the sheet
};
